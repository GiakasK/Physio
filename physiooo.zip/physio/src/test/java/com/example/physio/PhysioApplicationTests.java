package com.example.physio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhysioApplicationTests {

    @Test
    void contextLoads() {
    }

}
