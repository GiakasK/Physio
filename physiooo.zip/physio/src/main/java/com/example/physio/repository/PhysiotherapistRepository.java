package com.example.physio.repository;

import com.example.physio.model.Physiotherapist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PhysiotherapistRepository extends JpaRepository<Physiotherapist, Integer> {
}
