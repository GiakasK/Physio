package com.example.physio.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "treatment")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Treatment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "treatment_id")
    private Integer id;
    @Basic
    @Column
    private Integer treatmentNo;
    @Basic
    @Column
    private String name;
    @Enumerated(EnumType.ORDINAL)
    private TreatmentStatus status;

}
