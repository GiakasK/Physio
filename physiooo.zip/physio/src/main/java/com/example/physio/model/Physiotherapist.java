package com.example.physio.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "PHYSIOTHERAPIST")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Physiotherapist {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer id;
    @Basic
    @Column(length = 25)
    private String username;
    @Basic
    @Column(length = 60)
    private String password;
    @Basic
    @Column(length = 25)
    private String firstName;
    @Basic
    @Column(length = 25)
    private String lastName;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    @JoinColumn(name = "user_id")
    private final List<Client> clients = new ArrayList<>();

}
