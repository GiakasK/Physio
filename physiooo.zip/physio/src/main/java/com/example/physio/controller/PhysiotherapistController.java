package com.example.physio.controller;

import com.example.physio.service.PhysiotherapistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PhysiotherapistController {

    PhysiotherapistService physiotherapistService;

    @Autowired
    public PhysiotherapistController(PhysiotherapistService physiotherapistService) {
        this.physiotherapistService = physiotherapistService;
    }


    @GetMapping("/")
    public String getIndexPage(ModelMap modelMap) {
        modelMap.addAttribute("clientDTOs", physiotherapistService.getPhysiotherapistClients(1));
        return "clients";
    }

}
