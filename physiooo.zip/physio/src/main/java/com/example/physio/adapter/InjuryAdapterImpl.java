package com.example.physio.adapter;

import com.example.physio.adapter.definition.Adapter;
import com.example.physio.dto.InjuryDTO;
import com.example.physio.model.Injury;
import org.springframework.stereotype.Service;

@Service
public class InjuryAdapterImpl
        implements Adapter<Injury, InjuryDTO> {
    @Override
    public Injury transformDTOToEntity(InjuryDTO dto) {
        return Injury.builder()
                .name(dto.getName())
                .injuryDt(dto.getInjuryDt())
                .build();
    }

    @Override
    public InjuryDTO transformEntityToDTO(Injury entity) {
        return InjuryDTO.builder()
                .name(entity.getName())
                .injuryDt(entity.getInjuryDt())
                .build();
    }
}
