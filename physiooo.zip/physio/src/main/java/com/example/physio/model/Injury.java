package com.example.physio.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "injury")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Injury {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "injury_id")
    private Integer id;
    @Basic
    @Column(length = 25)
    private String name;
    @Basic
    @Column
    private LocalDate injuryDt;
}
