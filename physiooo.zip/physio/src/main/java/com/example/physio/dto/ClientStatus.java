package com.example.physio.dto;

public enum ClientStatus {

    ACTIVE("Active"),
    INACTIVE("Inactive");

    private String status;

    ClientStatus(String status) {
        this.status = status;
    }
}
