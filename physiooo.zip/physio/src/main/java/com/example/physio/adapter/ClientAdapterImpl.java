package com.example.physio.adapter;

import com.example.physio.adapter.definition.Adapter;
import com.example.physio.dto.ClientDTO;
import com.example.physio.dto.ClientStatus;
import com.example.physio.dto.InjuryDTO;
import com.example.physio.dto.TreatmentDTO;
import com.example.physio.model.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClientAdapterImpl
        implements Adapter<Client, ClientDTO> {

    InjuryAdapterImpl injuryAdapter;

    TreatmentAdapterImpl treatmentAdapter;

    @Autowired
    public ClientAdapterImpl(InjuryAdapterImpl injuryAdapter, TreatmentAdapterImpl treatmentAdapter) {
        this.injuryAdapter = injuryAdapter;
        this.treatmentAdapter = treatmentAdapter;
    }

    @Override
    public Client transformDTOToEntity(ClientDTO dto) {
        Client client = Client.builder()
                .id(dto.getId())
                .firstName(dto.getFirstName())
                .lastName(dto.getLastName())
                .birthDt(dto.getBirthDt())
                .mobilePhone(dto.getMobilePhone())
                .build();
        addInjuries(dto.getInjuries(), client);
        addTreatments(dto.getTreatments(), client);
        return client;
    }

    void addTreatments(List<TreatmentDTO> treatmentDTOS, Client client) {
        client.getTreatments().clear();
        client.getTreatments().addAll(
                treatmentDTOS.stream().map(treatmentAdapter::transformDTOToEntity).collect(Collectors.toList())
        );
    }

    void addInjuries(List<InjuryDTO> injuryDTOs, Client client) {
        client.getInjuries().clear();
        client.getInjuries().addAll(
                injuryDTOs.stream().map(injuryAdapter::transformDTOToEntity).collect(Collectors.toList())
        );
    }

    @Override
    public ClientDTO transformEntityToDTO(Client entity) {
        return ClientDTO.builder()
                .id(entity.getId())
                .firstName(entity.getFirstName())
                .lastName(entity.getLastName())
                .birthDt(entity.getBirthDt())
                .mobilePhone(entity.getMobilePhone())
                .status(entity.getTreatments().isEmpty() ? ClientStatus.INACTIVE : ClientStatus.ACTIVE)
                .injuries(entity.getInjuries().stream().map(injuryAdapter::transformEntityToDTO).collect(Collectors.toList()))
                .treatments(entity.getTreatments().stream().map(treatmentAdapter::transformEntityToDTO).collect(Collectors.toList()))
                .build();
    }
}
