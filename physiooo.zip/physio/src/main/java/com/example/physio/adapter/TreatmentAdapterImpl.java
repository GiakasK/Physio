package com.example.physio.adapter;

import com.example.physio.adapter.definition.Adapter;
import com.example.physio.dto.TreatmentDTO;
import com.example.physio.model.Treatment;
import com.example.physio.model.TreatmentStatus;
import org.springframework.stereotype.Service;

@Service
public class TreatmentAdapterImpl
        implements Adapter<Treatment, TreatmentDTO> {
    @Override
    public Treatment transformDTOToEntity(TreatmentDTO dto) {
        return Treatment.builder()
                .id(dto.getId())
                .name(dto.getName())
                .status(TreatmentStatus.valueOf(dto.getStatus()))
                .treatmentNo(dto.getTreatmentNo())
                .build();
    }

    @Override
    public TreatmentDTO transformEntityToDTO(Treatment entity) {
        return TreatmentDTO.builder()
                .id(entity.getId())
                .name(entity.getName())
                .status(entity.getStatus().getStatus())
                .treatmentNo(entity.getTreatmentNo())
                .build();
    }
}
