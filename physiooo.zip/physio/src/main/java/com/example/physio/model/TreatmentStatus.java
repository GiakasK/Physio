package com.example.physio.model;

public enum TreatmentStatus {

    PENDING("Pending"),
    ONGOING("Ongoing"),
    COMPLETED("Completed");

    private String status;

    TreatmentStatus(String status) {

        this.status = status;
    }

    public String getStatus() {

        return this.status;
    }
}
