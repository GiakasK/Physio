package com.example.physio.service;

import com.example.physio.adapter.ClientAdapterImpl;
import com.example.physio.dto.ClientDTO;
import com.example.physio.model.Physiotherapist;
import com.example.physio.repository.PhysiotherapistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PhysiotherapistService {

    PhysiotherapistRepository physiotherapistRepository;

    ClientAdapterImpl clientAdapter;

    @Autowired
    public PhysiotherapistService(PhysiotherapistRepository physiotherapistRepository, ClientAdapterImpl clientAdapter) {
        this.physiotherapistRepository = physiotherapistRepository;
        this.clientAdapter = clientAdapter;
    }

    public Collection<ClientDTO> getPhysiotherapistClients(Integer id) {
        Optional<Physiotherapist> physioOptional = physiotherapistRepository.findById(id);
        Physiotherapist physiotherapist = physioOptional.orElseGet(Physiotherapist::new);
        return physiotherapist.getClients().stream()
                .map(clientAdapter::transformEntityToDTO)
                .sorted(Comparator.comparing(ClientDTO::getStatus))
                .collect(Collectors.toList());
    }

}
