package com.example.physio.adapter.definition;

public interface Adapter<T, S> {

    T transformDTOToEntity(S dto);

    S transformEntityToDTO(T entity);
}
